package id.codex.stormlauncher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.SharedPreferences
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private var gameFolderUri: Uri? = null

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            gameFolderUri = uri
            prefs.edit().putString("game_folder", uri.toString()).apply()
            showHome()
            Toast.makeText(this, "Folder game disimpan.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("codex_settings", MODE_PRIVATE)
        gameFolderUri = prefs.getString("game_folder", null)?.let { Uri.parse(it) }
        showHome()
    }

    private fun setupRoot(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(Color.rgb(5, 14, 30))
        }
        root.addView(TextView(this).apply {
            text = "CODEX  /  NARUTO STORM CONNECTIONS\\n$title"
            textSize = 20f
            setTextColor(Color.rgb(100, 190, 255))
            setPadding(0, 0, 0, 20)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(0, 105, 230))
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) })
    }

    private fun label(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(2, 10, 2, 10)
        })
    }

    private fun showHome() {
        setupRoot("LAUNCHER BASE • v0.2.0")
        label("Game fokus: Naruto x Boruto: Ultimate Ninja Storm Connections (.exe)")
        label("Folder game: " + if (gameFolderUri == null) "Belum dipilih" else "Tersimpan")
        label("Perangkat: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
        button("Pilih Folder Game (.exe)") { folderPicker.launch(null) }
        button("Periksa File Game") { checkFolder() }
        button("Optimasi FPS") { showFps() }
        button("Pengaturan Grafik") { showGraphics() }
        button("Pengaturan Driver") { showDrivers() }
        button("Layout Tombol PS5") { showControls() }
        button("Jalankan Naruto Storm Connections") {
            Toast.makeText(this,
                "Folder EXE terpilih belum cukup untuk menjalankan game. Runtime Windows/kompatibilitas harus diintegrasikan terlebih dahulu.",
                Toast.LENGTH_LONG).show()
        }
        label("Launcher ini mengelola folder dan preferensi. Ia tidak mengubah FPS game sampai terhubung ke runtime yang mendukungnya.")
    }

    private fun checkFolder() {
        val uri = gameFolderUri
        if (uri == null) {
            Toast.makeText(this, "Pilih folder game terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val dir = DocumentFile.fromTreeUri(this, uri)
        val files = dir?.listFiles() ?: emptyArray()
        val exeFiles = files.filter { it.name?.endsWith(".exe", true) == true }
        val gameLikely = exeFiles.any {
            val n = it.name.orEmpty().lowercase()
            n.contains("storm") || n.contains("naruto") || n.contains("connections")
        }
        val message = when {
            gameLikely -> "File EXE yang namanya cocok ditemukan. Runtime Windows masih diperlukan."
            exeFiles.isNotEmpty() -> "Ada ${exeFiles.size} file EXE, tetapi nama EXE game belum teridentifikasi di folder tingkat ini."
            else -> "EXE tidak ditemukan di tingkat folder ini. Pilih folder yang benar atau periksa subfolder."
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun showFps() {
        setupRoot("OPTIMASI FPS")
        label("Preset awal untuk chipset kelas menengah. Ini menyimpan profil launcher; efek nyata memerlukan runtime yang membaca pengaturan ini.")
        choice("Preset performa", "fps_preset", listOf("Stabil (Disarankan)", "Seimbang", "Visual"))
        choice("Target FPS", "fps_target", listOf("30 FPS", "40 FPS", "60 FPS"))
        choice("Resolusi render", "fps_resolution", listOf("960 × 540", "1280 × 720", "1600 × 900", "1920 × 1080"))
        choice("Skala resolusi", "fps_scale", listOf("50%", "60%", "70%", "80%", "100%"))
        toggle("Mode hemat panas", "thermal_mode", true)
        toggle("Batasi proses latar belakang (preferensi)", "background_mode", true)
        toggle("V-Sync (jika runtime mendukung)", "vsync", false)
        toggle("Upscaling FSR (jika runtime mendukung)", "fsr", true)
        toggle("Shader cache (jika runtime mendukung)", "shader_cache", true)
        toggle("Tekstur", "fps_texture", false, listOf("Rendah", "Sedang", "Tinggi"))
        toggle("Bayangan", "fps_shadow", false, listOf("Mati", "Rendah", "Sedang"))
        button("Simpan Profil FPS") {
            Toast.makeText(this, "Profil FPS tersimpan. Belum diterapkan langsung ke EXE tanpa integrasi runtime.", Toast.LENGTH_LONG).show()
            showHome()
        }
        button("Kembali") { showHome() }
    }

    private fun showGraphics() {
        setupRoot("PENGATURAN GRAFIK")
        choice("Resolusi render", "graphics_resolution", listOf("960 × 540 (Ringan)", "1280 × 720", "1920 × 1080"))
        choice("Target FPS", "graphics_fps", listOf("30 FPS (Stabil)", "40 FPS", "60 FPS"))
        choice("Kualitas tekstur", "graphics_texture", listOf("Rendah", "Sedang", "Tinggi"))
        choice("Bayangan", "graphics_shadow", listOf("Mati", "Rendah", "Sedang", "Tinggi"))
        choice("Efek visual", "graphics_effects", listOf("Rendah", "Sedang", "Tinggi"))
        button("Simpan") { Toast.makeText(this, "Preferensi grafik disimpan.", Toast.LENGTH_SHORT).show(); showHome() }
        button("Kembali") { showHome() }
    }

    private fun showDrivers() {
        setupRoot("PENGATURAN DRIVER")
        label("Launcher tidak memasang atau mengganti driver GPU Android. Pilih backend preferensi yang akan digunakan bila runtime mendukungnya.")
        choice("Backend grafis", "driver_backend", listOf("Otomatis (Disarankan)", "Vulkan (jika tersedia)", "OpenGL (jika tersedia)"))
        choice("Profil perangkat", "device_profile", listOf("Deteksi otomatis", "Helio G99", "Dimensity 6080", "Snapdragon 680 atau lebih tinggi"))
        toggle("Gunakan opsi kompatibilitas (jika runtime mendukung)", "compat_mode", true)
        button("Simpan") { Toast.makeText(this, "Preferensi driver tersimpan; driver sistem tidak diubah.", Toast.LENGTH_LONG).show(); showHome() }
        button("Kembali") { showHome() }
    }

    private fun showControls() {
        setupRoot("LAYOUT TOMBOL • GAYA PS5")
        label("Pratinjau kontrol virtual (belum mengirim input ke game):")
        root.addView(TextView(this).apply {
            text = "L2       L1                         R1       R2\\n\\n        △                 ○\\n\\n   ◁          ✕          □\\n\\n      L3   [ D-PAD ]   R3\\n\\n       OPTIONS     PS"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(15, 35, 62))
            setPadding(10, 35, 10, 35)
        }, LinearLayout.LayoutParams(-1, -2))
        toggle("Tampilkan overlay (preferensi)", "controller_overlay", true)
        choice("Transparansi tombol", "controller_alpha", listOf("30%", "50%", "70%", "100%"))
        label("Pemetaan tombol ke game memerlukan runtime yang menyediakan injeksi input atau dukungan kontroler.")
        button("Kembali") { showHome() }
    }

    private fun choice(title: String, key: String, options: List<String>) {
        label(title)
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        val saved = prefs.getString(key, null)
        if (saved != null) {
            val index = options.indexOf(saved)
            if (index >= 0) spinner.setSelection(index)
        }
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putString(key, options[position]).apply()
            }
        }
        root.addView(spinner)
    }

    private fun toggle(title: String, key: String, default: Boolean, options: List<String>? = null) {
        if (options != null) {
            choice(title, key, options)
            return
        }
        val cb = CheckBox(this).apply {
            text = title
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(key, default)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(40, 160, 255))
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        root.addView(cb)
    }
}
