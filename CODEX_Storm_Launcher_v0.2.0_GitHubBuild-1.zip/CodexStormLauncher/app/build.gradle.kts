plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.codex.stormlauncher"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.codex.stormlauncher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
